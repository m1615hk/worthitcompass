import { useState } from 'react';

export default function Home() {
  const [answers, setAnswers] = useState({
    conviction: "",
    strength: "",
    marketNeed: "",
    scripture: "",
  });
  const [summary, setSummary] = useState("");

  const handleChange = (field) => (e) => {
    setAnswers({ ...answers, [field]: e.target.value });
  };

  const generateSummary = () => {
    const { conviction, strength, marketNeed, scripture } = answers;
    const page = `🧭 ONE-PAGE KINGDOM CLARITY\n---\n📖 Conviction: ${conviction}\n💪 Strength: ${strength}\n🌍 Market Need: ${marketNeed}\n📜 Anchoring Scripture: ${scripture}\n\n✨ Recommendation: Build something that honors your conviction, leverages your God-given strength, and meets this market need. Do it with eternity in mind.`;
    setSummary(page);
  };

  return (
    <div style={{ maxWidth: 600, margin: '2rem auto', fontFamily: 'sans-serif' }}>
      <h1>WorthIt Compass</h1>
      <p>Answer these 4 questions to find what’s truly worth doing:</p>
      <div>
        <label>1️⃣ Conviction:</label><br/>
        <textarea onChange={handleChange("conviction")} /><br/>
        <label>2️⃣ Strength:</label><br/>
        <textarea onChange={handleChange("strength")} /><br/>
        <label>3️⃣ Market Need:</label><br/>
        <textarea onChange={handleChange("marketNeed")} /><br/>
        <label>4️⃣ Scripture:</label><br/>
        <input onChange={handleChange("scripture")} /><br/><br/>
        <button onClick={generateSummary}>📄 Generate Summary</button>
      </div>
      {summary && <pre style={{ background: '#f0f0f0', padding: '1rem' }}>{summary}</pre>}
    </div>
  );
}